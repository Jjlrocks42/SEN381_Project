﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Sql;
using System.Data.Common;
using System.Security.Cryptography.X509Certificates;
using System.Runtime.CompilerServices;
using System.Data.SqlClient;
using System.Data;

namespace SEN381_Project.Layers.Data_Access_Layer
{
    class Data_Handler
    {
        // Only common generic methods exists for all derived classes.
        interface IDataProvider
        {
            void OpenConnection();
            void CloseConnection();
        }

        // Implement methods specific to the respective derived classe
        interface ISqlDataProvider : IDataProvider,IDataManipulator
        {
            DataTable ExecuteSqlCommand(string command);
        }

        interface IDataManipulator
        {
            void ExecuteNoQuery(string command);
        }

        // Client 1
        // Should not force SqlDataProvider client to implement ExecuteOracleCommand, as it wont required that method to be implemented.
        // So that we will derive ISqlDataProvider not IOracleDataProvider
        class SqlDataClient : ISqlDataProvider
        {
            SqlConnection conn = new SqlConnection("Data Source = (local); Initial Catalog=DBpremier_service_solutions;Integrated Security=SSPI");
            //Open connection
            public void OpenConnection()
            {
                try
                {
                    conn.Open();
                    Console.WriteLine("\nSql Connection opened successfully");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\nConnection Failed: " + e);
                    //MessageBox.Show("Database connection unsuccessfull", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                //return 1;
            }

            //close connection
            public void CloseConnection()
            {
                if (conn != null)
                {
                    conn.Close();
                }
                //return 1;
            }

            //make adustable according to recieved queries
            public DataTable ExecuteSqlCommand(string command)
            {
                DataTable dt = new DataTable();
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(command, conn);
                    da.Fill(dt);
                    Console.WriteLine("\nData Retrieved");
                }
                catch (Exception e)
                {
                    Console.WriteLine("Incorrect sql statement");
                }
                return dt;
            }

            public void ExecuteNoQuery(string command)
            {
                try
                {

                }
                catch (Exception e)
                {

                }
            }

        }


        class InterfaceSegregationPrincipleDemo
        {
            public static void ISPDemo()
            {
                Console.WriteLine("\n\nInterface Inversion Principle Demo ");

                // Each client will implement their respective methods no base class forces the other client to implement the methods which dont required.
                // From the above implementation, we are not forcing Sql client to implemnt orcale logic or Oracle client to implement sql logic.

                ISqlDataProvider SqlDataProviderObject = new SqlDataClient();
                SqlDataProviderObject.OpenConnection();
                SqlDataProviderObject.ExecuteSqlCommand("SELECT * FROM Customer");
                SqlDataProviderObject.CloseConnection();

            }

        }
    }
}

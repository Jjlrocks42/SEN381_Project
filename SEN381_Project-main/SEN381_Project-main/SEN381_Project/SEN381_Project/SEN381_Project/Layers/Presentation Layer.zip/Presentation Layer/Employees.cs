﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Calls
{
    public partial class Employees : Form
    {
        public Employees()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Calls
{
    public partial class Contracts : Form
    {
        public Contracts()
        {
            InitializeComponent();
        }

        private void Contracts_Load(object sender, EventArgs e)
        {

        }

        private void BtnShow_Click(object sender, EventArgs e)
        {

        }
    }
}
